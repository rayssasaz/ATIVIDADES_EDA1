#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filapri.h"
int main()
{
    char nome[51];
    FILAPRIO *fp = NULL;

    fp = criaFila();

    printf("A fila de atendimento possui %d pacientes. \n\n", tamFilaPrio(fp));

    confInsert(insertFilaPrio(fp, "Marcelo Dantas", 2));
    confInsert(insertFilaPrio(fp, "Jose da Silva", 4));
    confInsert(insertFilaPrio(fp, "Joao Martins", 5));
    confInsert(insertFilaPrio(fp, "Claudio Menezes", 0));
    confInsert(insertFilaPrio(fp, "Antonio Angelo", 4));

    printf("A fila de atendimento possui %d pacientes. \n\n", tamFilaPrio(fp));

    listaFilaPrio(fp);

    printf("\n\n");

    while(consultaFilaPrio(fp, nome)){
        printf("Chamando para atendimento o paciente: %s\n", nome);
        removeFilaPrio(fp);
    }
    printf("N�o ha mais pacientes para serem atendidos. \n\n");

    liberaFilaPrio(fp);

    return 0;
}
