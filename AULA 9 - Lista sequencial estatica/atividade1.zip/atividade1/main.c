#include <stdio.h>
#include <stdlib.h>
#include "listaest.h"


int main()
{
    int x;
    Lista *li;
    li = crialista();

    x = tamanho_lista(li);
    printf("Tamanho da lista: %d \n", x);

    x = lista_cheia(li);
    if(x){
        printf("Lista cheia!\n");
    }
    else{
        printf("A lista nao esta cheia!\n");
    }

    x = lista_vazia(li);
    if(x){
        printf("Lista vazia!\n");
    }
    else{
        printf("A lista nao esta vazia!\n");
    }

    // INSER��O DE DADOS
        int mat = 110, posicao = 1;
        struct aluno al, al2, al3, dados_aluno;

        al.matricula = 100;
        al.n1 = 5.3;
        al.n2 = 6.9;
        al.n3 = 7.4;

        al2.matricula = 120;
        al2.n1 = 4;
        al2.n2 = 2.9;
        al2.n3 = 8.4;

        al3.matricula = 110;
        al3.n1 = 1.3;
        al3.n2 = 2.9;
        al3.n3 = 3.4;

        x = insere_lista_final(li, al2);
        if(x){
        printf("\nAluno inserido com sucesso!");
        }
        else{
            printf("\nErro aluno nao inserido!");
        }
        x = insere_lista_inicio(li, al);
        if(x){
            printf("\nAluno inserido com sucesso!");
        }else{
            printf("\nErro aluno nao inserido!");
        }


        x = insere_lista_ordenada(li, al3);
        if(x){
            printf("\nAluno inserido com sucesso!");
        }else{
            printf("\nErro aluno nao inserido!");
        }


        x = remove_lista_final(li);
        if(x){
            printf("\nAluno removido com sucesso!");
        }else{
            printf("\nErro aluno nao removido!");
        }

        x = remove_lista_inicio(li);
        if(x){
            printf("\nAluno removido com sucesso!");
        }else{
            printf("\nErro aluno nao removido!");
        }

        x = remove_lista(li, mat);
        if(x){
            printf("\nAluno removido na posicao especificada com sucesso!");
        }else{
            printf("\nErro aluno nao removido na posicao especificada!");
        }

        x = consulta_lista_mat(li, posicao, &dados_aluno);
        if(x){
            printf("\nConsulta por posicao bem sucedida!\n");
            printf("Matricula: %d \n", dados_aluno.matricula);
            printf("Nota 1: %.2f \n", dados_aluno.n1);
            printf("Nota 2: %.2f \n", dados_aluno.n2);
            printf("Nota 3: %.2f \n", dados_aluno.n3);
        }
        else{
            printf("\nNao foi possivel consultar na posicao especificada");
        }

        x = consulta_lista_pos(li, mat, &dados_aluno);
        if(x){
            printf("\nConsulta por matricula bem sucedida!\n");
            printf("Matricula: %d \n", dados_aluno.matricula);
            printf("Nota 1: %.2f \n", dados_aluno.n1);
            printf("Nota 2: %.2f \n", dados_aluno.n2);
            printf("Nota 3: %.2f \n", dados_aluno.n3);
        }
        else{
            printf("\nNao foi possivel consultar na matricula especificada");
        }

        int i = 0;
        struct aluno aluno_entrada;

        for(i = 0; i < 10; i++){
            aluno_entrada = coletaDados();
            x = insere_lista_ordenada(li, aluno_entrada);
            if(x){
                printf("\nAluno %d inserido com sucesso!", i + 1);
            }else{
                printf("\nErro aluno %d nao inserido!", i + 1);
            }
        }

        x = consulta_lista_pos(li, posicao, &aluno_entrada);
        if(x){
            printf("\n\nConsulta por posicao bem sucedida!\n");
            printf("Matricula: %d \n", aluno_entrada.matricula);
            printf("Nota 1: %.2f \n", aluno_entrada.n1);
            printf("Nota 2: %.2f \n", aluno_entrada.n2);
            printf("Nota 3: %.2f \n", aluno_entrada.n3);
        }
        else{
            printf("\n\nNao foi possivel consultar na posicao especificada");
        }

    return 0;
}
