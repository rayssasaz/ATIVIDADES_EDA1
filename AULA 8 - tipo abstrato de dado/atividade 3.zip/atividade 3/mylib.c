#include <stdio.h>
#include <stdlib.h>
#include"mylib.h"

struct operacoes {
    float x;
    float y;
    float r;
};

OP *novaOP(){
    OP *p = (OP*) malloc(sizeof(OP));
    if(p!=NULL){
        p->x = 0;  // O -> � uma forma abreviada de fazer (*p).x.
        p->y = 0;
        p->r = 0;
    }
    return p;
}

void liberaOP(OP *p){
    free(p);
}


void finformar(OP *p, float x, float y){             // retorna os valores x e y que o usuario entrar
    p -> x = x;
    p -> y = y;
}

void fsoma(OP *p){
    p->r = p->x + p->y;
}

void fsubt(OP *p){
    p->r = p->x - p->y;
}

void fmult(OP *p){
    p->r = p->x * p->y;

}

void fdivisao(OP *p){
    p->r = p->x / p->y;
}

float resultado(OP *p){
    return p->r;
}
