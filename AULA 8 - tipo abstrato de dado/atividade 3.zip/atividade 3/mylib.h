
typedef struct operacoes OP;

// cria uma nova opera��o
OP *novaOP();

//libera op
void liberaOP(OP *p);



// case 1 - o usuario informa os valores
void finformar(OP *p, float x, float y); // retorna os valores x e y que o usuario entrar

void fsoma(OP *p);
void fsubt(OP *p);
void fmult(OP *p);
void fdivisao(OP *p);
float resultado(OP *p);











