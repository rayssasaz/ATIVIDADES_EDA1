#include <stdio.h>
#include <stdlib.h>
#include"mylib.h"
int main()
{
    OP *p = NULL;
    p = novaOP();
    float x = 0,y = 0;
    int resp;

    while(1){
        // text menu
        printf("Escolha uma opcao: \n 1 - Informar \n 2 - Soma \n 3 - Subtracao\n 4 - Multiplicacao \n 5 - Divisao\n 6 - ver R\n 7 - sair\n ");
        scanf("%d", &resp);

        printf("\n\n\n");

        //montar switch case
        switch(resp){
            case 1:
                printf("Digite o primeiro valor: ");
                scanf("%f", &x);
                printf("Digite o segundo valor: ");
                scanf("%f", &y);
                finformar(p, x, y);
                break;
            case 2:
                fsoma(p);
                break;
            case 3:
                fsubt(p);
                break;
            case 4:
                fmult(p);
                break;
            case 5:
                if(y == 0){
                    printf("Erro (divisao por 0)\n");
                }
                fdivisao(p);
                break;
            case 6:
                printf("\nultimo resultado: %.2f\n", resultado(p));
                break;
            case 7:
                exit(0);
                break;
            default:
                printf("Erro!\n");
        }

    }

    liberaOP(p);


    return 0;
}

