void calculoVantagens(float numH, float salH, int numF, float valorF, float *SB, float *SF, float *VT);
void calculoDeducoes(float tax, float *SB, float *inss, float *irpf, float *ded);

