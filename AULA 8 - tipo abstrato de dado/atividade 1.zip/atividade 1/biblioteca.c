#include<stdio.h>
#include<stdlib.h>
#include"biblioteca.h"

void calculoVantagens(float numH, float salH, int numF, float valorF, float *SB, float *SF, float *VT){

    *SB = numH * salH;
    *SF = numF * valorF;
    *VT = *SB + *SF;
}


void calculoDeducoes(float tax, float *SB, float *inss, float *irpf, float *ded){
    *inss = *SB * 0.08;
    *irpf = *SB * tax;
    *ded = *inss + *irpf;
}




