#include <stdio.h>
#include <stdlib.h>
#include "listaligada.h"
int main()
{

    int x;
    Lista *li = NULL;
    if((li = criaLista()) == NULL){
        abortaPrograma();
    }
    /*
    x = tamanhoLista(li);
    printf("O tamanho da lista e: %d", x);

    if(listaCheia(li)){
        printf("\nLista cheia!");
    }
    else{
        printf("\nLista nao esta cheia");
    }

    if(listaVazia(li)){
        printf("\nLista vazia!");
    }
    else{
        printf("\nLista nao esta vazia");
    }


    x = 0;
    int matricula = 120, posicao = 2;


    if((li = criaLista()) == NULL)
    {
        abortaPrograma();
    }

    ALUNO al_consulta, al1, al2, al3;

    al1.matricula = 110;
    al1.n1 = 5.6;
    al1.n2 = 6.3;
    al1.n3 = 7.9;

    al2.matricula = 130;
    al2.n1 = 9.2;
    al2.n2 = 3.5;
    al2.n3 = 8.1;

    al3.matricula = 120;
    al3.n1 = 6.6;
    al3.n2 = 2.1;
    al3.n3 = 9.2;

    x = insereInicio(li, al1);
    if(x){
        printf("\nAluno %d inserido no inico com sucesso!", x);
    }else{
        printf("\nNao foi possivel inserir no inicio.");
    }
    //  verifica novamente se a lista esta vazia
    if(listaVazia(li)){
        printf("\nLista vazia!");
    }
    else{
        printf("\nLista nao esta vazia");
    }

    x = insereFinal(li, al2);
    if(x){
        printf("\nAluno %d inserido no final com sucesso!", x);
    }else{
        printf("\nNao foi possivel inserir no final.");
    }

    x = insereOrdenado(li, al3);
    if(x){
        printf("\nAluno %d inserido ordenadamente com sucesso!", x);
    }else{
        printf("\nNao foi possivel inserir ordenadamente.");
    }

    x = tamanhoLista(li);
    printf("\nO tamanho da lista e: %d alunos\n", x);

    x = consultaPosicao(li, posicao, &al_consulta);
    if(x){
        printf("\n\nCOnsulta na posicao %d: ", posicao);
        printf("\nMatricula: %d", al_consulta.matricula);
        printf("\nNota 1:    %.2f", al_consulta.n1);
        printf("\nNota 2:    %.2f", al_consulta.n2);
        printf("\nNota 3:    %.2f", al_consulta.n3);
    } else{
        printf("\nPosicao %d nao existe.", posicao);
    }

    x = consultaMatricula(li, matricula, &al_consulta);
    if(x){
        printf("\n\nCOnsulta aluno matriculado %d: ", al_consulta.matricula);
        printf("\nMatricula: %d", al_consulta.matricula);
        printf("\nNota 1:    %.2f", al_consulta.n1);
        printf("\nNota 2:    %.2f", al_consulta.n2);
        printf("\nNota 3:    %.2f", al_consulta.n3);
    } else{
        printf("\Matricula %d nao encontrada.", matricula);
    }

    x = removeOrdenado(li, matricula);
    if(x){
        printf("\n\nAluno %d removido ordenadamente com sucesso!", x);
    }else{
        printf("\n\nNao foi possivel remover o aluno %d.", x);
    }

    x = consultaMatricula(li, matricula, &al_consulta);
    if(x){
        printf("\n\nConsulta aluno matriculado %d: ", al_consulta.matricula);
        printf("\nMatricula: %d", al_consulta.matricula);
        printf("\nNota 1:    %.2f", al_consulta.n1);
        printf("\nNota 2:    %.2f", al_consulta.n2);
        printf("\nNota 3:    %.2f", al_consulta.n3);
    } else{
        printf("\nMatricula %d nao encontrada.", matricula);
    }

    x = consultaPosicao(li, posicao, &al_consulta);
    if(x){
        printf("\n\nConsulta na posicao %d: ", posicao);
        printf("\nMatricula: %d", al_consulta.matricula);
        printf("\nNota 1:    %.2f", al_consulta.n1);
        printf("\nNota 2:    %.2f", al_consulta.n2);
        printf("\nNota 3:    %.2f", al_consulta.n3);
    } else{
        printf("\nPosicao %d nao existe.", posicao);
    }

    x = removeFinal(li);
    if(x){
        printf("\nAluno %d removido do final com sucesso!\n", x);
    }else{
        printf("\nNao foi possivel remover no final.");
    }

    x = removeInicio(li);
    if(x){
        printf("\nAluno %d removido do inicio com sucesso!", x);
    }else{
        printf("\nNao foi possivel remover no inicio.");
    }
    */
    int matricula, op;
    ALUNO al_consulta;

    while(1){
        printf("\nO que voce deseja?\n");

        printf("1 - Inserir um aluno \n");
        printf("2 - Buscar um aluno (por matricula)\n");
        printf("3 - Remover um aluno\n");
        printf("4 - Encerrar o programa\n");

        scanf("%d", &op);
        system("cls");

        switch(op){
            case 1:
                x = insereOrdenado(li, coletaDados());
                if(x){
                    printf("\nAluno %d inserido ordenadamente com sucesso!\n", x);
                }else{
                    printf("\nNao foi possivel inserir ordenadamente.");
                }
                system("cls");
                break;
            case 2:
                printf("\nMatricula do aluno: ");
                scanf("%d", &matricula);
                x = consultaMatricula(li, matricula, &al_consulta);
                if(x){
                    printf("\n\n\tRelatorio do Aluno ");
                    printf("\nMatricula: %d", al_consulta.matricula);
                    printf("\nNota 1:    %.2f", al_consulta.n1);
                    printf("\nNota 2:    %.2f", al_consulta.n2);
                    printf("\nNota 3:    %.2f\n", al_consulta.n3);
                } else{
                    printf("\nMatricula %d nao encontrada.\n", matricula);
                }
                system("pause");
                system("cls");
                break;
            case 3:
                printf("\nMatricula do aluno: ");
                scanf("%d", &matricula);
                x = removeOrdenado(li, matricula);
                if(x){
                    printf("\n\nAluno %d removido ordenadamente com sucesso!\n", x);
                }else{
                    printf("\n\nNao foi possivel remover o aluno %d.\n", x);
                }
                system("pause");
                system("cls");
                break;
            case 4:
                printf("\nEncerrando o programa...\n");
                exit(0);
                break;
            default:
                printf("\nErro! Opcao invalida!\n");
                system("pause");
                system("cls");
                break;
        }
    }

    apagaLista(li);
    return 0;
}
