#include <stdio.h>
#include <stdlib.h>
#include "listadupla.h"

int main()
{
    int x, matricula = 110, pos = 3;
    ALUNO al, al1, al2, al3;

    al1.matricula = 100;
    al1.n1 = 8.3;
    al1.n2 = 8.4;
    al1.n3 = 8.5;

    al2.matricula = 110;
    al2.n1 = 7.3;
    al2.n2 = 7.4;
    al2.n3 = 7.5;

    al3.matricula = 120;
    al3.n1 = 6.3;
    al3.n2 = 6.4;
    al3.n3 = 6.5;

    LISTA *li;

    li = criaLista();

    x = tamanhoLista(li);
    printf("O tamamho da lista e %d\n", x);


    x = listaCheia(li);
    if(x){
        printf("A lista esta cheia!\n");
    }else{
        printf("A lista nao esta cheia\n");
    }

    x = listaVazia(li);
    if(x){
        printf("A lista esta vazia!\n");
    }else{
        printf("A lista nao esta vazia\n");
    }

    x = insereInicio(li, al1);
    if(x){
        printf("Aluno %d inserido no inicio com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao inserido.");
    }

    x = insereFinal(li, al3);
    if(x){
        printf("Aluno %d inserido o final com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao inserido.");
    }

    x = insereOrdenado(li, al2);
    if(x){
        printf("Aluno %d inserido ordenadamente com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao inserido.");
    }

    x = removeInicio(li);
    if(x){
        printf("Aluno %d removido do inicio com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao removido.");
    }

    x = removeFinal(li);
    if(x){
        printf("Aluno %d removido do final com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao removido.");
    }

    x = removeOrdenado(li, matricula);
    if(x){
        printf("Aluno %d removido ordenadamente com sucesso!\n", x);
    }else{
        printf("Erro! aluno nao removido.");
    }

    x = consultaPosicao(li, pos, &al);
    if(x){
        printf("\n\nCOnsulta na posicao %d: ", pos);
        printf("\nMatricula: %d", al.matricula);
        printf("\nNota 1:    %.2f", al.n1);
        printf("\nNota 2:    %.2f", al.n2);
        printf("\nNota 3:    %.2f", al.n3);
    } else{
        printf("\nPosicao %d nao existe.", pos);
    }

    x = consultaMatricula(li, matricula, &al);
    if(x){
        printf("\n Consulta aluno matriculado:");
        printf("\nMatricula: %d", al.matricula);
        printf("\nNota 1: %.2f", al.n1);
        printf("\nNota 2: %.2f", al.n2);
        printf("\nNota 3: %.2f", al.n3);
    }else{
        printf("\nMatricula %d n encontrada", matricula);
    }

    //apagaLista()
    return 0;
}
